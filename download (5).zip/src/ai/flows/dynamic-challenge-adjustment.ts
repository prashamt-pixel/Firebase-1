'use server';

/**
 * @fileOverview This file defines a Genkit flow for dynamically adjusting daily challenge difficulty based on player skill.
 *
 * The flow uses player analytics to determine the appropriate difficulty level for daily challenges.
 * It exports the `adjustChallengeDifficulty` function, the `AdjustChallengeDifficultyInput` type, and the `AdjustChallengeDifficultyOutput` type.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AdjustChallengeDifficultyInputSchema = z.object({
  playerLevel: z.number().describe('The current level of the player.'),
  averageScore: z.number().describe('The average score of the player in recent games.'),
  completionRate: z.number().describe('The rate at which the player completes daily challenges (0 to 1).'),
  daysPlayed: z.number().describe('Number of days the player has played the game'),
});
export type AdjustChallengeDifficultyInput = z.infer<
  typeof AdjustChallengeDifficultyInputSchema
>;

const AdjustChallengeDifficultyOutputSchema = z.object({
  adjustedDifficulty: z
    .string()
    .describe(
      'The adjusted difficulty level for the next daily challenge (Easy, Medium, Hard).'
    ),
  reasoning: z
    .string()
    .describe(
      'Explanation of why the difficulty was adjusted to the current level.'
    ),
});
export type AdjustChallengeDifficultyOutput = z.infer<
  typeof AdjustChallengeDifficultyOutputSchema
>;

export async function adjustChallengeDifficulty(
  input: AdjustChallengeDifficultyInput
): Promise<AdjustChallengeDifficultyOutput> {
  return adjustChallengeDifficultyFlow(input);
}

const adjustChallengeDifficultyPrompt = ai.definePrompt({
  name: 'adjustChallengeDifficultyPrompt',
  input: {schema: AdjustChallengeDifficultyInputSchema},
  output: {schema: AdjustChallengeDifficultyOutputSchema},
  prompt: `You are an AI game designer tasked with adjusting the difficulty of daily challenges for a player in BlastGrid. The goal is to keep the player engaged by providing challenges that are neither too easy nor too hard.

  Here is the player's data:
  - Player Level: {{{playerLevel}}}
  - Average Score: {{{averageScore}}}
  - Daily Challenge Completion Rate: {{{completionRate}}}
  - Days Played: {{{daysPlayed}}}

  Based on this data, determine the appropriate difficulty level for the next daily challenge. Consider these factors:
  - A low completion rate (below 0.5) suggests the challenges are too difficult.
  - A high completion rate (above 0.8) suggests the challenges are too easy.
  - Average score relative to player level can indicate skill and engagement.
  - The number of days played can indicate expertise and progression.

  Output the adjusted difficulty level (Easy, Medium, or Hard) and a brief explanation of your reasoning.

  Difficulty: {{adjustedDifficulty}}
  Reasoning: {{reasoning}}`,
});

const adjustChallengeDifficultyFlow = ai.defineFlow(
  {
    name: 'adjustChallengeDifficultyFlow',
    inputSchema: AdjustChallengeDifficultyInputSchema,
    outputSchema: AdjustChallengeDifficultyOutputSchema,
  },
  async input => {
    const {output} = await adjustChallengeDifficultyPrompt(input);
    return output!;
  }
);
