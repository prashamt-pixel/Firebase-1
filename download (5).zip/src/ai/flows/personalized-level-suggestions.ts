'use server';

/**
 * @fileOverview This file defines a Genkit flow for providing personalized level suggestions based on player history and skill.
 *
 * The flow takes player data as input and outputs a suggested level ID.
 * The file exports:
 * - `suggestLevel(input: SuggestLevelInput): Promise<SuggestLevelOutput>` - The function to call to get a level suggestion.
 * - `SuggestLevelInput` - The type definition for the input to the suggestLevel function.
 * - `SuggestLevelOutput` - The type definition for the output of the suggestLevel function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Define the input schema
const SuggestLevelInputSchema = z.object({
  playerHistory: z
    .array(z.object({levelId: z.string(), score: z.number()}))
    .describe('The player history including level ID and score for each level.'),
  currentSkillLevel: z
    .number()
    .describe('The current skill level of the player (e.g., 1-10).'),
  gameAnalytics: z
    .string()
    .optional()
    .describe('Current status of game analytics pertaining to progression unlocks.'),
});
export type SuggestLevelInput = z.infer<typeof SuggestLevelInputSchema>;

// Define the output schema
const SuggestLevelOutputSchema = z.object({
  suggestedLevelId: z
    .string()
    .describe('The ID of the suggested level for the player.'),
  reason: z
    .string()
    .describe('The reason why this level was suggested for the player.'),
});
export type SuggestLevelOutput = z.infer<typeof SuggestLevelOutputSchema>;

// Define the prompt
const suggestLevelPrompt = ai.definePrompt({
  name: 'suggestLevelPrompt',
  input: {schema: SuggestLevelInputSchema},
  output: {schema: SuggestLevelOutputSchema},
  prompt: `You are an expert game designer. Suggest a level for the player based on their play history and current skill level, incorporating game analytics pertaining to progression unlocks.

Player History: {{playerHistory}}
Current Skill Level: {{currentSkillLevel}}
Game Analytics: {{gameAnalytics}}

Consider the player's performance on previous levels, their current skill level, and game analytics regarding progression unlocks when suggesting the next level.

{{#if gameAnalytics}}
Based on the game analytics, prioritize levels that align with the game's progression goals and encourage player engagement.
{{/if}}

Suggest a level ID that would be appropriate for the player and justify your choice.
`,
});

// Define the flow
const suggestLevelFlow = ai.defineFlow(
  {
    name: 'suggestLevelFlow',
    inputSchema: SuggestLevelInputSchema,
    outputSchema: SuggestLevelOutputSchema,
  },
  async input => {
    const {output} = await suggestLevelPrompt(input);
    return output!;
  }
);

/**
 * Suggests a level for the player based on their play history and current skill level.
 * @param input The input data containing player history and skill level.
 * @returns The suggested level ID and the reason for the suggestion.
 */
export async function suggestLevel(input: SuggestLevelInput): Promise<SuggestLevelOutput> {
  return suggestLevelFlow(input);
}
