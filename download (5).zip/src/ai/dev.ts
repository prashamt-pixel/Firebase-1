import { config } from 'dotenv';
config();

import '@/ai/flows/dynamic-challenge-adjustment.ts';
import '@/ai/flows/personalized-level-suggestions.ts';