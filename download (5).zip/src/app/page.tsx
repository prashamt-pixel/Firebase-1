import { Header } from '@/components/layout/header';
import { MainDashboard } from '@/components/layout/main-dashboard';
import { PLAYER_STARTING_STATS } from '@/lib/constants';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header playerStats={PLAYER_STARTING_STATS} />
      <main className="flex-1">
        <MainDashboard />
      </main>
    </div>
  );
}
