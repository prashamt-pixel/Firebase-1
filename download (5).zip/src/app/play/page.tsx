import { GameBoard } from '@/components/game/game-board';
import { GameControls } from '@/components/game/game-controls';
import { GameHeader } from '@/components/game/game-header';
import { Button } from '@/components/ui/button';
import { PLAYER_STARTING_STATS } from '@/lib/constants';
import { Home } from 'lucide-react';
import Link from 'next/link';

export default function PlayPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary flex flex-col items-center justify-between p-2 sm:p-4">
      <div className="w-full max-w-sm">
        <GameHeader playerStats={PLAYER_STARTING_STATS} />
      </div>

      <GameBoard />

      <div className="w-full max-w-sm">
        <GameControls />
      </div>
      
      <div className="absolute top-4 left-4 z-10">
        <Link href="/" passHref>
          <Button variant="secondary" className="shadow-md h-auto py-1 px-2 text-xs sm:py-2 sm:px-3 sm:text-sm">
            <Home className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
            Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}
