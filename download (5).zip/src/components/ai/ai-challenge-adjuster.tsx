"use client";

import { useState } from 'react';
import { adjustChallengeDifficulty, type AdjustChallengeDifficultyOutput } from '@/ai/flows/dynamic-challenge-adjustment';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Bot, Loader2, Wand2 } from 'lucide-react';

export function AiChallengeAdjuster() {
  const [result, setResult] = useState<AdjustChallengeDifficultyOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAdjustDifficulty = async () => {
    setIsLoading(true);
    setResult(null);
    try {
      const output = await adjustChallengeDifficulty({
        playerLevel: 15,
        averageScore: 12500,
        completionRate: 0.9,
        daysPlayed: 30,
      });
      setResult(output);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-background/50">
        <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                Challenge Adjuster
            </CardTitle>
            <CardDescription>Let AI dynamically adjust challenge difficulty.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <Button onClick={handleAdjustDifficulty} disabled={isLoading} className="w-full">
            {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
                <Wand2 className="mr-2 h-4 w-4" />
            )}
            Adjust Difficulty
            </Button>
            {result && (
                <Alert>
                    <AlertTitle>Next Challenge: {result.adjustedDifficulty}</AlertTitle>
                    <AlertDescription>{result.reasoning}</AlertDescription>
                </Alert>
            )}
        </CardContent>
    </Card>
  );
}
