"use client";

import { useState } from 'react';
import { suggestLevel, type SuggestLevelOutput } from '@/ai/flows/personalized-level-suggestions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot, Lightbulb, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';

export function AiLevelSuggester() {
  const [suggestion, setSuggestion] = useState<SuggestLevelOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSuggestLevel = async () => {
    setIsLoading(true);
    setSuggestion(null);
    try {
      const result = await suggestLevel({
        playerHistory: [
          { levelId: '1-1', score: 5200 },
          { levelId: '1-2', score: 4800 },
        ],
        currentSkillLevel: 3,
        gameAnalytics: 'Player needs to be guided towards World 2 unlock.',
      });
      setSuggestion(result);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-background/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            Level Suggester
        </CardTitle>
        <CardDescription>Get a personalized level suggestion from our AI.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={handleSuggestLevel} disabled={isLoading} className="w-full">
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Lightbulb className="mr-2 h-4 w-4" />
          )}
          Suggest a Level
        </Button>
        {suggestion && (
            <Alert>
                <AlertTitle>AI Suggestion: Play Level {suggestion.suggestedLevelId}</AlertTitle>
                <AlertDescription>
                    {suggestion.reason}
                </AlertDescription>
            </Alert>
        )}
      </CardContent>
    </Card>
  );
}
