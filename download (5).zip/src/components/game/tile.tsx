"use client";

import type { TileData } from '@/lib/types';
import { cn } from '@/lib/utils';
import { useEffect, useState } from 'react';

type TileProps = {
  tile: TileData;
  onClick: () => void;
};

// This function needs to be defined within the client component or imported from a client-side module.
function darkenColor(hex: string, percent: number): string {
    if (hex === 'transparent' || !hex.startsWith('#')) return 'transparent';
    try {
        let f=parseInt(hex.slice(1),16),t=percent<0?0:255,p=percent<0?percent*-1:percent,R=f>>16,G=f>>8&0x00FF,B=f&0x0000FF;
        return "#"+(0x1000000+(Math.round((t-R)*p)+R)*0x10000+(Math.round((t-G)*p)+G)*0x100+(Math.round((t-B)*p)+B)).toString(16).slice(1);
    } catch (e) {
        return 'transparent';
    }
}


export function Tile({ tile, onClick }: TileProps) {
  const isExploding = tile.state === 'exploding';
  const isEmpty = tile.state === 'empty';
  const [borderColor, setBorderColor] = useState('transparent');

  useEffect(() => {
      // Deferring browser-specific calculation to client-side only
      setBorderColor(darkenColor(tile.color, 20));
  }, [tile.color]);


  return (
    <div
      onClick={isEmpty ? undefined : onClick}
      className={cn(
        'w-9 h-9 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-lg transition-all duration-300 flex items-center justify-center shadow-md border-b-4 relative overflow-hidden',
        !isEmpty && 'cursor-pointer',
        isEmpty && 'bg-transparent shadow-none border-none pointer-events-none',
        isExploding && 'animate-pop'
      )}
      style={{ 
        backgroundColor: isEmpty ? 'transparent' : tile.color,
        borderColor: isEmpty ? 'transparent' : borderColor,
       }}
    >
      {!isEmpty && !isExploding && (
        <>
          <div className="absolute top-1 left-1 w-3/4 h-3/4 bg-white/25 rounded-full blur-sm" />
          <div className="w-3/4 h-3/4 bg-white/20 rounded-md transform rotate-45" />
        </>
      )}
    </div>
  );
}
