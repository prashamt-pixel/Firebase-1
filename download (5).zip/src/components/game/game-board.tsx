"use client";

import { useState, useEffect } from 'react';
import { Tile } from './tile';
import type { TileData } from '@/lib/types';
import { GRID_HEIGHT, GRID_WIDTH, TILE_COLORS } from '@/lib/constants';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';

const generateLevel = (): TileData[][] => {
  return Array.from({ length: GRID_HEIGHT }, (_, rowIndex) =>
    Array.from({ length: GRID_WIDTH }, (_, colIndex) => ({
      id: `tile-${rowIndex}-${colIndex}-${Math.random()}`,
      color: TILE_COLORS[Math.floor(Math.random() * TILE_COLORS.length)],
      state: 'idle',
    }))
  );
};

export function GameBoard() {
  const [grid, setGrid] = useState<TileData[][]>([]);
  const [score, setScore] = useState(0);

  useEffect(() => {
    setGrid(generateLevel());
  }, []);

  const findConnectedTiles = (row: number, col: number, color: string): {row: number, col: number}[] => {
    const connected: {row: number, col: number}[] = [];
    const visited = new Set<string>();
    const queue = [{row, col}];
    visited.add(`${row},${col}`);

    while(queue.length > 0) {
        const current = queue.shift()!;
        connected.push(current);

        const neighbors = [
            {row: current.row - 1, col: current.col}, // up
            {row: current.row + 1, col: current.col}, // down
            {row: current.row, col: current.col - 1}, // left
            {row: current.row, col: current.col + 1}, // right
        ];

        for (const neighbor of neighbors) {
            if (
                neighbor.row >= 0 && neighbor.row < GRID_HEIGHT &&
                neighbor.col >= 0 && neighbor.col < GRID_WIDTH &&
                grid[neighbor.row][neighbor.col].color === color &&
                !visited.has(`${neighbor.row},${neighbor.col}`)
            ) {
                visited.add(`${neighbor.row},${neighbor.col}`);
                queue.push(neighbor);
            }
        }
    }
    return connected;
  };


  const handleTileClick = (row: number, col: number) => {
    const tile = grid[row][col];
    if (tile.state !== 'idle' || tile.color === 'transparent') return;

    const connectedTiles = findConnectedTiles(row, col, tile.color);

    if (connectedTiles.length < 2) return;

    let newGrid = grid.map(r => r.slice());
    connectedTiles.forEach(t => {
      newGrid[t.row][t.col] = { ...newGrid[t.row][t.col], state: 'exploding' };
    });
    setGrid(newGrid);

    setTimeout(() => {
      let afterExplosionGrid = newGrid.map(r => r.slice());
      connectedTiles.forEach(t => {
        afterExplosionGrid[t.row][t.col] = { ...afterExplosionGrid[t.row][t.col], state: 'empty', color: 'transparent' };
      });
      
      // Gravity
      for (let c = 0; c < GRID_WIDTH; c++) {
          let emptyRow = GRID_HEIGHT - 1;
          for (let r = GRID_HEIGHT - 1; r >= 0; r--) {
              if (afterExplosionGrid[r][c].state !== 'empty') {
                  if (r !== emptyRow) {
                    afterExplosionGrid[emptyRow][c] = afterExplosionGrid[r][c];
                    afterExplosionGrid[r][c] = { id: `empty-${r}-${c}`, color: 'transparent', state: 'empty' };
                  }
                  emptyRow--;
              }
          }
      }

      // Refill
      for (let r = 0; r < GRID_HEIGHT; r++) {
        for (let c = 0; c < GRID_WIDTH; c++) {
            if (afterExplosionGrid[r][c].state === 'empty') {
                afterExplosionGrid[r][c] = {
                    id: `tile-refill-${r}-${c}-${Math.random()}`,
                    color: TILE_COLORS[Math.floor(Math.random() * TILE_COLORS.length)],
                    state: 'idle'
                };
            }
        }
      }

      setGrid(afterExplosionGrid);
      setScore(prev => prev + connectedTiles.length * 10);

    }, 300);
  };
  
  if (grid.length === 0) {
    return (
      <Card className="p-4 bg-background/80 shadow-lg backdrop-blur-sm">
        <div className="text-lg font-semibold">Loading Board...</div>
      </Card>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
        <div className="flex justify-between w-full max-w-sm">
            <Card className="shadow-md">
                <CardContent className="p-3 w-36 text-center">
                    <div className="text-sm font-medium text-muted-foreground">SCORE</div>
                    <div className="text-2xl font-bold">{score.toLocaleString()}</div>
                </CardContent>
            </Card>
            <Card className="shadow-md">
                <CardContent className="p-3 w-36 text-center">
                    <div className="text-sm font-medium text-muted-foreground">GOAL</div>
                    <div className="text-2xl font-bold">5,000</div>
                </CardContent>
            </Card>
        </div>
      <Card className="p-1 sm:p-2 bg-background/50 shadow-lg backdrop-blur-sm">
        <div
          className="grid gap-1"
          style={{
            gridTemplateColumns: `repeat(${GRID_WIDTH}, 1fr)`,
          }}
        >
          {grid.map((row, rowIndex) =>
            row.map((tile, colIndex) => (
              <Tile
                key={tile.id}
                tile={tile}
                onClick={() => handleTileClick(rowIndex, colIndex)}
              />
            ))
          )}
        </div>
      </Card>
      <Button onClick={() => { setGrid(generateLevel()); setScore(0); }}>
        <RefreshCw className="mr-2 h-4 w-4" />
        Reset Board
      </Button>
    </div>
  );
}
