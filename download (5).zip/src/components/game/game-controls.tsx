import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { STORE_ITEMS } from "@/lib/constants";
import { Hammer, Shuffle, Bomb } from "lucide-react";

export function GameControls() {
    const powerups = STORE_ITEMS.filter(item => ['shuffle', 'hammer', 'bomb'].includes(item.id));
    
    return (
        <Card className="shadow-lg w-full">
            <CardContent className="p-2 flex justify-around items-center">
                {powerups.map((powerup) => (
                    <Button key={powerup.id} variant="outline" size="lg" className="flex flex-col h-auto p-2 gap-1 aspect-square w-20">
                        <powerup.icon className="h-6 w-6" />
                        <span className="text-xs">{powerup.name}</span>
                    </Button>
                ))}
            </CardContent>
        </Card>
    );
}
