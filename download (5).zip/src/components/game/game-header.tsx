import { Coins, Gem, Heart, Star } from 'lucide-react';
import type { PlayerStats } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';

type GameHeaderProps = {
  playerStats: PlayerStats;
};

export function GameHeader({ playerStats }: GameHeaderProps) {
  return (
    <Card className="shadow-md w-full">
      <CardContent className="p-2 flex justify-around items-center">
        <div className="flex items-center gap-2" title="Lives">
          <Heart className="h-5 w-5 text-red-500 fill-red-500" />
          <span className="font-bold text-lg">{playerStats.lives}</span>
        </div>
        <div className="flex items-center gap-2" title="Coins">
          <Coins className="h-5 w-5 text-orange-400" />
          <span className="font-bold text-lg">{playerStats.coins.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-2" title="Gems">
          <Gem className="h-5 w-5 text-purple-400" />
          <span className="font-bold text-lg">{playerStats.gems?.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-2" title="Level">
            <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
            <span className="font-bold text-lg">{playerStats.level}</span>
        </div>
      </CardContent>
    </Card>
  );
}
