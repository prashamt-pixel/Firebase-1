"use client";

import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Gift, Video } from "lucide-react";

export function RewardedAdCard() {
    const { toast } = useToast();

    const handleWatchAd = () => {
        // Simulate watching an ad
        toast({
            title: "Ad Watched!",
            description: "You received a free Bomb power-up.",
        })
    }

  return (
    <div className="p-4 bg-accent/20 border border-accent rounded-lg flex flex-col items-center text-center gap-2">
      <div className="p-2 bg-accent/20 rounded-full">
        <Gift className="h-6 w-6 text-accent-foreground" />
      </div>
      <h4 className="font-semibold text-accent-foreground">Free Power-up!</h4>
      <p className="text-sm text-accent-foreground/80">Watch a short ad to get a random free power-up.</p>
      <Button variant="default" className="w-full bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleWatchAd}>
        <Video className="mr-2 h-4 w-4" />
        Watch Ad
      </Button>
    </div>
  );
}
