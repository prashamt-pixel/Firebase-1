"use client";

import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { STORE_ITEMS } from "@/lib/constants";
import type { StoreItem } from "@/lib/types";
import { Coins } from "lucide-react";

export function ShopItemCard({ item }: { item: StoreItem }) {
    const { toast } = useToast();

    const handleBuy = () => {
        toast({
            title: "Purchase Successful!",
            description: `You bought 1x ${item.name}.`,
        });
    }

    return (
        <div className="flex items-center justify-between p-3 bg-secondary rounded-lg border">
            <div className="flex items-center gap-4">
                <div className="p-2 bg-background rounded-md">
                    <item.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                    <h4 className="font-semibold">{item.name}</h4>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
            </div>
            <Button size="sm" onClick={handleBuy}>
                <Coins className="mr-2 h-4 w-4" />
                {item.price}
            </Button>
        </div>
    );
}
