import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { STORE_ITEMS } from "@/lib/constants";
import { Coins, Store } from "lucide-react";
import { ShopItemCard } from "./shop-item-card";

export function StoreDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
            <Store className="mr-2 h-4 w-4" />
            Visit Store
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Store className="h-6 w-6 text-primary" />
            Power-up Store
          </DialogTitle>
          <DialogDescription>
            Spend your coins on powerful items to help you beat tough levels.
          </DialogDescription>
        </DialogHeader>
        <Separator />
        <div className="flex items-center justify-end gap-2 text-lg font-bold text-orange-500">
            <Coins className="h-6 w-6"/>
            <span>500</span>
        </div>
        <div className="space-y-4 py-4">
            {STORE_ITEMS.map(item => (
                <ShopItemCard key={item.id} item={item} />
            ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
