import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MOCK_CHALLENGE } from "@/lib/constants";
import { Calendar, Coins, Gift } from "lucide-react";

export function DailyChallengeCard() {
    return (
        <Card className="bg-gradient-to-br from-secondary to-background">
            <CardHeader>
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                        <Calendar className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                        <CardTitle>Daily Challenge</CardTitle>
                        <CardDescription>{MOCK_CHALLENGE.title}</CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <p className="text-foreground/80">{MOCK_CHALLENGE.description}</p>
                <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                    <div className="flex items-center gap-2">
                        <Gift className="h-5 w-5 text-accent"/>
                        <span className="font-semibold">Reward</span>
                    </div>
                    <div className="flex items-center gap-2 font-bold text-accent">
                        <Coins className="h-5 w-5"/>
                        <span>{MOCK_CHALLENGE.reward.amount}</span>
                    </div>
                </div>
                <Button className="w-full bg-primary hover:bg-primary/90">Start Challenge</Button>
            </CardContent>
        </Card>
    );
}
