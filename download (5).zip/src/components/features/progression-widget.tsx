import Image from "next/image";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export function ProgressionWidget() {
    const progressionMapImage = PlaceHolderImages.find(p => p.id === 'progression-map');

    return (
        <Card>
            <CardHeader>
                <CardTitle>Your Journey</CardTitle>
                <CardDescription>Explore new worlds as you complete levels.</CardDescription>
            </CardHeader>
            <CardContent>
                {progressionMapImage && (
                    <div className="aspect-[4/3] relative rounded-lg overflow-hidden border-2 border-accent/50 shadow-inner">
                        <Image
                            src={progressionMapImage.imageUrl}
                            alt={progressionMapImage.description}
                            data-ai-hint={progressionMapImage.imageHint}
                            fill
                            className="object-cover"
                        />
                         <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                         <div className="absolute bottom-4 left-4">
                            <h3 className="text-white text-2xl font-bold">World 1: Crystal Caves</h3>
                            <p className="text-white/80">You are on Level 1-5</p>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
