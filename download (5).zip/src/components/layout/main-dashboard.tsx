"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DailyChallengeCard } from '@/components/features/daily-challenge-card';
import { RewardedAdCard } from '@/components/features/rewarded-ad-card';
import { StoreDialog } from '@/components/features/store-dialog';
import { ProgressionWidget } from '@/components/features/progression-widget';
import { AiLevelSuggester } from '@/components/ai/ai-level-suggester';
import { AiChallengeAdjuster } from '@/components/ai/ai-challenge-adjuster';
import { Play } from 'lucide-react';

export function MainDashboard() {
  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 space-y-8">
          <Card className="bg-primary/20 border-primary/30 overflow-hidden shadow-lg">
            <div className="p-8 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
              <div>
                <h2 className="text-3xl font-bold font-headline text-primary-foreground">Ready for a new Blast?</h2>
                <p className="text-primary-foreground/80 mt-2 max-w-md">Jump into the action and start clearing the grid. New challenges await!</p>
              </div>
              <Link href="/play" passHref>
                <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 transform hover:scale-105 transition-transform duration-200 shadow-xl min-w-[200px]">
                  Play Level 1
                  <Play className="ml-2 h-5 w-5 fill-current" />
                </Button>
              </Link>
            </div>
          </Card>
          
          <ProgressionWidget />
          
          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Tools</CardTitle>
              <CardDescription>Use GenAI to personalize your game experience.</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <AiLevelSuggester />
              <AiChallengeAdjuster />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          <DailyChallengeCard />
          <Card>
            <CardHeader>
              <CardTitle>Get Power-ups!</CardTitle>
              <CardDescription>Need a boost? Visit the store or watch an ad for rewards.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <StoreDialog />
              <RewardedAdCard />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
