import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Coins, Crown, Star } from 'lucide-react';
import { Logo } from '@/components/icons';
import type { PlayerStats } from '@/lib/types';
import { PlaceHolderImages } from '@/lib/placeholder-images';

type HeaderProps = {
  playerStats: PlayerStats;
};

export function Header({ playerStats }: HeaderProps) {
  const avatarImage = PlaceHolderImages.find(p => p.id === 'player-avatar');
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-sm">
      <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
        <div className="flex gap-4 items-center">
          <Logo className="h-8 w-8 text-primary" />
          <h1 className="text-2xl font-bold font-headline text-primary-foreground">BlastGrid</h1>
        </div>
        
        <div className="flex flex-1 items-center justify-end space-x-4">
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center gap-2" title="Level">
              <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
              <span className="font-semibold">{playerStats.level}</span>
            </div>
            <div className="flex items-center gap-2" title="Score">
              <Crown className="h-5 w-5 text-amber-500 fill-amber-500" />
              <span className="font-semibold">{playerStats.score.toLocaleString()}</span>
            </div>
             <div className="flex items-center gap-2" title="Coins">
              <Coins className="h-5 w-5 text-orange-400" />
              <span className="font-semibold">{playerStats.coins.toLocaleString()}</span>
            </div>
          </div>
          <Avatar>
            {avatarImage && <AvatarImage src={avatarImage.imageUrl} alt={avatarImage.description} data-ai-hint={avatarImage.imageHint} />}
            <AvatarFallback>P</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
