export type TileData = {
  id: string;
  color: string;
  state: 'idle' | 'exploding' | 'empty';
};

export type PlayerStats = {
  level: number;
  score: number;
  coins: number;
  lives?: number;
  gems?: number;
};

export type DailyChallenge = {
  title: string;
  description: string;
  reward: {
    type: 'coins' | 'powerup';
    amount: number;
  };
};

export type StoreItem = {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  price: number;
};
