import { Bomb, Shuffle, Zap, Hammer } from 'lucide-react';
import type { DailyChallenge, PlayerStats, StoreItem } from './types';

export const GRID_WIDTH = 8;
export const GRID_HEIGHT = 8;

export const TILE_COLORS = [
  '#ff6b6b', // Red
  '#48dbfb', // Blue
  '#1dd1a1', // Green
  '#feca57', // Yellow
  '#ff9f43', // Orange
  '#706fd3', // Purple
];

export const STORE_ITEMS: StoreItem[] = [
  {
    id: 'bomb',
    name: 'Bomb',
    description: 'Clears a 3x3 area.',
    icon: Bomb,
    price: 100,
  },
  {
    id: 'zap',
    name: 'Line Clear',
    description: 'Clears an entire row.',
    icon: Zap,
    price: 150,
  },
  {
    id: 'shuffle',
    name: 'Shuffle',
    description: 'Shuffles all blocks on the board.',
    icon: Shuffle,
    price: 200,
  },
  {
    id: 'hammer',
    name: 'Hammer',
    description: 'Clears a single block.',
    icon: Hammer,
    price: 50,
  }
];

export const PLAYER_STARTING_STATS: PlayerStats = {
    level: 1,
    score: 0,
    coins: 500,
    lives: 5,
    gems: 50,
};

export const MOCK_CHALLENGE: DailyChallenge = {
    title: "Terrific Tuesday",
    description: "Score 5,000 points in a single game.",
    reward: { type: 'coins', amount: 250 }
}
